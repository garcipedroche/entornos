package refactorizacion3;

import java.util.ArrayList;

import JUnit.Teclado;

/**
 * Clase Musica
 * 
 * Implementa el m�todo main() que cree una orquesta con todos un instrumento de
 * cada tipo.
 * 
 * Implementa un m�todo afinarTodos() que afine todos los instrumentos.
 * 
 * Implementa un m�todo tocarTodos() que toque todos los instrumentos.
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 */

public class Musica {

	public static void main(String[] args) {
		ArrayList ejemploInfer = new ArrayList();
		ejemploInfer.add(new Cuerda());
		
		Instrumento[] orquesta= crearOrquesta();

		System.out.println("Afinamos todos los instrumentos: ");
		afinarTodos(orquesta);

		System.out.println("A tocar: ");
		do {
			tocarTodos(orquesta, obtenerNota());

		} while (deseaContinuar());

	}

	private static Instrumento[] crearOrquesta() {
		Instrumento orquesta[] = new Instrumento[3];
		orquesta[0] = new Cuerda();
		System.out.println(orquesta[0].queSoy());
		orquesta[1] = new Viento();
		System.out.println(orquesta[1].queSoy());
		orquesta[2] = new Percusion();
		System.out.println(orquesta[2].queSoy());
		return orquesta;
	}

	private static boolean deseaContinuar() {
		String cadena = Teclado.leerCadena(
				"�Quieres que siga tocando la orquesta?").toUpperCase();
		if (cadena.equals("SI")) {
			return true;
		} else{
			System.out.println("ADIOS");
			return false;
		}
	}

	/**
	 * Tocar todos los instrumentos
	 * 
	 * @param orquesta
	 * @param nota
	 *            a tocar por los instrumentos
	 * 
	 */
	private static void tocarTodos(Instrumento[] orquesta, Nota nota) {
		for (int i = 0; i < orquesta.length; i++) {
			orquesta[i].tocar(nota);
		}
	}

	/**
	 * Obtener nota de la enumeracion
	 * 
	 * @return Nota de la enum
	 */
	private static Nota obtenerNota() {
		String opcion = pedirNota();
		switch (opcion) {
		case "DO":
			return Nota.DO;
		case "RE":
			return Nota.RE;
		case "MI":
			return Nota.MI;
		case "FA":
			return Nota.FA;
		case "SOL":
			return Nota.SOL;
		case "LA":
			return Nota.LA;
		default:
			return Nota.SI;
		}

	}

	/**
	 * Pedir nota al usuario
	 * 
	 * @return nota valida
	 */

	private static String pedirNota() {

		String aux = Teclado.leerCadena("Dime la nota que quieres tocar: ")
				.toUpperCase();
		Boolean notaValida;
		do {
			notaValida = comprobarNota(aux);
			if (notaValida == true) {

				return aux;

			} else
				aux = Teclado.leerCadena(
						"Nota no valida. Introduce una nota valida.")
						.toUpperCase();

		} while (!notaValida);

		return null;
	}

	/**
	 * Comprobar si la nota introducida por el usuario es valida
	 * 
	 * @param nota
	 *            a comprobar
	 * @return true si es una nota valida false en el resto de los casos
	 */
	private static boolean comprobarNota(String nota) {
		if (nota.equals("DO") || nota.equals("RE") || nota.equals("MI") || nota.equals("FA")
				|| nota.equals("SOL") || nota.equals("LA") || nota.equals("SI")) {
			return true;
		} else
			return false;

	}

	/**
	 * Afinar todos los instrumentos
	 * 
	 * @param orquesta
	 */
	private static void afinarTodos(Instrumento[] orquesta) {
		for (int i = 0; i < orquesta.length; i++) {
			orquesta[i].afinar();
		}
	}

}
