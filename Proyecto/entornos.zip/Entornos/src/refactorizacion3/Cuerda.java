package refactorizacion3;

/**
 * Clase Cuerda que hereda de Instrumento
 * 
 * Implementa los m�todos necesarios (que muestre mensaje y argumento si lo
 * tiene)
 * 
 * redefine el m�todo queSoy() que devuelva la cadena "Instrumento de Cuerda"
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public class Cuerda extends Instrumento {

	public String queSoy() {
		return super.queSoy() + " de " + getClass().getSimpleName();

	}

	@Override
	void tocar(Nota nota) {
		System.out.println("Tocando la nota " + nota);
	}

	@Override
	void afinar() {
		System.out.println("Afinando " + queSoy());
		tocar(Nota.DO);
		tocar(Nota.RE);
		tocar(Nota.MI);
		System.out.println("Afinado");
	}

}
