package refactorizacion3;

/**
 * Clase Percusion que hereda de Instrumento
 * 
 * Implementa los m�todos necesarios (que muestre mensaje y argumento si lo
 * tiene)
 * 
 * redefine el m�todo queSoy() que devuelva la cadena "Instrumento de Percusi�n"
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public class Percusion extends Instrumento {

	public String queSoy() {
		return "Instrumento de Percusion";

	}

	@Override
	void tocar(Nota nota) {
		System.out.println("Tocando la nota " + nota);
	}

	@Override
	void afinar() {
		System.out.println("Afinando " + queSoy());
		tocar(Nota.FA);
		tocar(Nota.SOL);
		tocar(Nota.LA);
		System.out.println("Afinado");
	}

}
