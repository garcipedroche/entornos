package refactorizacion3;

/**
 * Clase abstracta Instrumento:
 * 
 * campo privado i
 * 
 * m�todo abstracto tocar(Nota)
 * 
 * m�todo p�blico queSoy() que devuelva la cadena "Instrumento"
 * 
 * m�todo abstracto afinar(); Para futuras implementaciones, recuerda que para
 * afinar hay que tocar un conjunto de notas.
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public abstract class Instrumento {
	private String i;

	abstract void tocar(Nota nota);

	abstract void afinar();

	public String queSoy() {
		return "Instrumento";
	}
}
