package refactorizacion3;

/**
 * Clase Viento que hereda de Instrumento
 * 
 * Implementa los m�todos necesarios (que muestre mensaje y argumento si lo
 * tiene)
 * 
 * redefine el m�todo queSoy() que devuelva la cadena "Instrumento de Viento"
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public class Viento extends Instrumento {

	public String queSoy() {
		return "Instrumento de Viento";

	}

	@Override
	void tocar(Nota nota) {
		System.out.println("Tocando la nota " + nota);
	}

	@Override
	void afinar() {
		System.out.println("Afinando " + queSoy());
		tocar(Nota.SI);
		tocar(Nota.DO);
		tocar(Nota.RE);
		System.out.println("Afinado");
	}

}
