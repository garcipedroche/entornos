/**
 * Paquete documentacion1 donde almaceno todas las clases y enumeraciones que requieren la funcionalidad
 */
/**
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 *
 */
package documentacion1;