package documentacion1;

/**
 * Enumeraci�n Nota
 * 
 * Toma los siete valores constantes DO, RE, MI, FA, SOL, LA, SI.
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public enum Nota {

	DO, RE, MI, FA, SOL, LA, SI;

}
