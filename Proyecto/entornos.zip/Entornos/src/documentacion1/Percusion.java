package documentacion1;

/**
 * Clase Percusion que hereda de Instrumento
 * 
 * Implementa los m�todos necesarios (que muestre mensaje y argumento si lo
 * tiene)
 * 
 * redefine el m�todo queSoy() que devuelva la cadena "Instrumento de Percusi�n"
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public class Percusion extends Instrumento {
	/**
	 * Metodo queSoy que muestra el estado del instrumento de Percusion. Hereda
	 * de instrumentro
	 */
	public String queSoy() {
		return "Instrumento de Percusion";

	}

	/**
	 * Metodo tocar que muestra la nota que se le manda por parametro
	 * 
	 * @param Nota
	 *            de la enumeracion Nota
	 */
	@Override
	void tocar(Nota nota) {
		System.out.println("Tocando la nota " + nota);
	}

	/**
	 * Metodo afinar. Muestra el estado del instrumento y toca algunas notas que
	 * afinan el instrumento
	 */

	@Override
	void afinar() {
		System.out.println("Afinando " + queSoy());
		tocar(Nota.FA);
		tocar(Nota.SOL);
		tocar(Nota.LA);
		System.out.println("Afinado");
	}

}
