package documentacion1;

/**
 * Clase Viento que hereda de Instrumento
 * 
 * Implementa los m�todos necesarios (que muestre mensaje y argumento si lo
 * tiene)
 * 
 * redefine el m�todo queSoy() que devuelva la cadena "Instrumento de Viento"
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public class Viento extends Instrumento {
	/**
	 * Metodo queSoy que muestra el estado del instrumento de viento. Hereda de
	 * instrumentro
	 */
	public String queSoy() {
		return "Instrumento de Viento";

	}

	/**
	 * Metodo tocar que muestra la nota que se le manda por parametro
	 * 
	 * @param Nota
	 *            de la enumeracion Nota
	 */
	@Override
	void tocar(Nota nota) {
		System.out.println("Tocando la nota " + nota);
	}

	/**
	 * Metodo afinar. Muestra el estado del instrumento y toca algunas notas que
	 * afinan el instrumento
	 */

	@Override
	void afinar() {
		System.out.println("Afinando " + queSoy());
		tocar(Nota.SI);
		tocar(Nota.DO);
		tocar(Nota.RE);
		System.out.println("Afinado");
	}

}
