package documentacion1;

/**
 * Clase Cuerda que hereda de Instrumento
 * 
 * Implementa los m�todos necesarios (que muestre mensaje y argumento si lo
 * tiene)
 * 
 * redefine el m�todo queSoy() que devuelva la cadena "Instrumento de Cuerda"
 * 
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 * 
 */
public class Cuerda extends Instrumento {
	/**
	 * Metodo queSoy que muestra el estado del instrumento de cuerda. Hereda de
	 * instrumentro
	 */
	public String queSoy() {
		return super.queSoy() + " de " + getClass().getSimpleName();

	}

	/**
	 * Metodo tocar que muestra la nota que se le manda por parametro
	 * 
	 * @param Nota
	 *            de la enumeracion Nota
	 */
	@Override
	void tocar(Nota nota) {
		System.out.println("Tocando la nota " + nota);
	}

	/**
	 * Metodo afinar. Muestra el estado del instrumento y toca algunas notas que
	 * afinan el instrumento
	 */
	@Override
	void afinar() {
		System.out.println("Afinando " + queSoy());
		tocar(Nota.DO);
		tocar(Nota.RE);
		tocar(Nota.MI);
		System.out.println("Afinado");
	}

}
