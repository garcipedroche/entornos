/**
 * Paquete documentacion2 donde almaceno todas las clases que tienen utilidades que van a ser utilizadas en las clases del paquete documentacion1 
 */
/**
 * @author Jose Manuel Garcia Valverde
 * @version 1.0
 *
 */
package documentacion2;